<!DOCTYPE html>
<html>
	<head>
    	<meta charset="utf-8">
			<title> Kennesaw State University </title>
			<link rel="stylesheet" href="style.css">
	</head>
	<body>
		<nav>
			<div class="wrapper">
				<ul>
					<li><a href="index.html">Home</a></li>
					<li><a href="aboutksu.html">About KSU</a></li>
					<li><a href="admissions.html">Admissions</a></li>
				</ul>
			</div>
		</nav>
		<div class="wrapper">
			<h1> Home </h1>
<a href="http://ccse.kennesaw.edu/it">
	<img src="https://iteach.kennesaw.edu/images/MB_Vert_3Clr.png" alt="W3Schools.com" style="width:104px;height:142px;"></a>
<br/>

<br/>



			<br/>
  <h2>Welcome to IT 5443 Web Development Milestone #1 HTML/CSS</h2>

			<br/>

			<br/>
  <h3>Course Description</h3>
  	<p class="paragraph">
			<br/>
      This course introduces World Wide Web as a fundamental application platform for today's information
 			systems. Students will examine core aspects of web technologies, web applications and will develop secured usable websites.
			<br/>
			This course is part of MSIT foundation courses that aims to provide a quick coverage of fundamental IT knowledge that is needed for later MSIT studies.Ts.
		</p>
		<br/>
	<h4> Course Objectives</h4>
		<br/>
		<ol
			<li>Explain different components of World Wide Web as a platform.</li>
			<li>Design and develop websites using fundamental web languages, technologies, and tools.</li>
			<li>Distinguish between server-side and client-side web technologies</li>
			<li>Analyze user experienc, usability and accessibility issues related to web sites.</li>
			<li>Evaluate various web application development issues and trends.</li>
			<li>Conduct independent research on a subject related to the course material</li>
		</ol>
	<h3>Latest KSU News</h3>
	 	<p class="paragraph">
			<br/>
			OwlFit Group fitness Classes are back in session!
			<br/>
			View the Schedule here: <a href="https://sportsrec.kennesaw.edu/owlfit/groupfitness/schedule-classdescriptions.php">
				sportsrec.kennesaw.edu/owlfit/groupfitness/schedule-classdescriptions.php</a>.
			<br/>
			It offers a variety of group fitness classes suitable for all experience and fitness levels.
			fitness classes are free to KSU students and Sports and Recreation members.
			We recommend that you arrive 10 minutes earlyto class and bring your Talon card
			<br/>
			<br/>
			<br/>
	<br/>


	  </div>
<footer>
	<p>Web Page created by: Bilikisu Shinaba</p>
	<p>Link to class website: <a href="http://it5443.azurewebsites.net">it5443.azurewebsites.net</a>.
	</p>
</footer>
	<p><strong>Note:</strong>This is a class project for IT 5443 Project Milestone
		Web Development</p>
</body>
</html>
